//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Login()
{
	truclient_step("1", "Navigate to '127.0.0.1:8080'", "snapshot=Login_1.inf");
	truclient_step("2", "Click on login link", "snapshot=Login_2.inf");
	truclient_step("3", "Authenticate", "snapshot=Login_3.inf");
	{
		truclient_step("3.1", "Type admin in Login textbox", "snapshot=Login_3.1.inf");
		truclient_step("3.2", "Type ***** in Password passwordbox", "snapshot=Login_3.2.inf");
		truclient_step("3.3", "Click on Authenticate button", "snapshot=Login_3.3.inf");
	}

	return 0;
}
