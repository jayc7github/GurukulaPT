//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

AddBranches()
{
	truclient_step("1", "Click on Entities link", "snapshot=AddBranches_1.inf");
	truclient_step("2", "Click on Branch link", "snapshot=AddBranches_2.inf");
	truclient_step("3", "Click on Create a new Branch button", "snapshot=AddBranches_3.inf");
	truclient_step("4", "Save", "snapshot=AddBranches_4.inf");
	{
		truclient_step("4.1", "Click on Name This field is required.... textbox", "snapshot=AddBranches_4.1.inf");
		truclient_step("4.2", "Type TC.getParam('pBranch') in Name This field is required.... textbox", "snapshot=AddBranches_4.2.inf");
		truclient_step("4.3", "Click on Code This field is required.... textbox", "snapshot=AddBranches_4.3.inf");
		truclient_step("4.4", "Type TC.getParam('pBranchno') in Code This field is required.... textbox", "snapshot=AddBranches_4.4.inf");
		truclient_step("4.5", "Click on Save button", "snapshot=AddBranches_4.5.inf");
	}

	return 0;
}
