//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

AddStaff()
{
	truclient_step("1", "Click on Entities link", "snapshot=AddStaff_1.inf");
	truclient_step("2", "Click on Staff link", "snapshot=AddStaff_2.inf");
	truclient_step("3", "Click on Create a new Staff button", "snapshot=AddStaff_3.inf");
	truclient_step("4", "Save", "snapshot=AddStaff_4.inf");
	{
		truclient_step("4.1", "Click on Name This field is required.... textbox", "snapshot=AddStaff_4.1.inf");
		truclient_step("4.2", "Type TC.getParam('pStaff') in Name This field is required.... textbox", "snapshot=AddStaff_4.2.inf");
		truclient_step("4.3", "Select TC.getParam('pSbranchno') from Branch BranchoneBranchtwo listbox", "snapshot=AddStaff_4.3.inf");
		truclient_step("4.4", "Click on Save button", "snapshot=AddStaff_4.4.inf");
	}

	return 0;
}
