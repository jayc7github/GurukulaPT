//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action_Staff()
{
	truclient_step("1", "If ( TC.getParam('pgroupname'... == 'thirdgroup' )", "snapshot=Action_Staff_1.inf");
	{
		truclient_step("1.1", "Click on Entities link", "snapshot=Action_Staff_1.1.inf");
		lr_start_transaction("GAWEB_10_Open_Staff_Page");
		truclient_step("1.2", "Click on Staff link", "snapshot=Action_Staff_1.2.inf");
		lr_end_transaction("GAWEB_10_Open_Staff_Page",0);
		truclient_step("1.3", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Staff_1.3.inf");
		lr_start_transaction("GAWEB_11_Scroll_One_Staff_Page");
		truclient_step("1.4", "Click on >", "snapshot=Action_Staff_1.4.inf");
		lr_end_transaction("GAWEB_11_Scroll_One_Staff_Page",0);
		truclient_step("1.5", "Wait TC.getParam('ptthigh') seconds", "snapshot=Action_Staff_1.5.inf");
		lr_start_transaction("GAWEB_12_Scroll_Staff_to_Last_Page");
		truclient_step("1.6", "Click on >&gt;", "snapshot=Action_Staff_1.6.inf");
		lr_end_transaction("GAWEB_12_Scroll_Staff_to_Last_Page",0);
		truclient_step("1.7", "Wait TC.getParam('ptthigh') seconds", "snapshot=Action_Staff_1.7.inf");
		truclient_step("1.8", "Click on Search Branch textbox", "snapshot=Action_Staff_1.8.inf");
		truclient_step("1.9", "Type TC.getParam('pSearchStaff') in Search Branch textbox", "snapshot=Action_Staff_1.9.inf");
		lr_start_transaction("GAWEB_13_Search_for_Staff");
		truclient_step("1.10", "Click on Search a Staff button", "snapshot=Action_Staff_1.10.inf");
		lr_end_transaction("GAWEB_13_Search_for_Staff",0);
		truclient_step("1.11", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Staff_1.11.inf");
		lr_start_transaction("GAWEB_14_View_a_Staff_Record");
		truclient_step("1.12", "Click on / View button", "snapshot=Action_Staff_1.12.inf");
		lr_end_transaction("GAWEB_14_View_a_Staff_Record",0);
		truclient_step("1.13", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Staff_1.13.inf");
		lr_start_transaction("GAWEB_16_Back_from_View_Staff_Record");
		truclient_step("1.14", "Click on Back button", "snapshot=Action_Staff_1.14.inf");
		lr_end_transaction("GAWEB_16_Back_from_View_Staff_Record",0);
		truclient_step("1.15", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Staff_1.15.inf");
		truclient_step("1.16", "If ( Math.random() <0.5 )", "snapshot=Action_Staff_1.16.inf");
		{
			lr_start_transaction("GAWEB_14_Open_Staff_Record_to_Edit");
			truclient_step("1.16.1", "Click on / Edit button", "snapshot=Action_Staff_1.16.1.inf");
			lr_end_transaction("GAWEB_14_Open_Staff_Record_to_Edit",0);
			truclient_step("1.16.2", "Wait TC.getParam('pttlow') seconds", "snapshot=Action_Staff_1.16.2.inf");
			truclient_step("1.16.3", "Save", "snapshot=Action_Staff_1.16.3.inf");
			{
				truclient_step("1.16.3.1", "Select var textArray = ['Branch...ay[randomNumber] from Branch BranchoneBranchtwo... listbox", "snapshot=Action_Staff_1.16.3.1.inf");
				lr_start_transaction("GAWEB_15_Save_an_Edited_Staff_Record");
				truclient_step("1.16.3.2", "Click on Save button", "snapshot=Action_Staff_1.16.3.2.inf");
				lr_end_transaction("GAWEB_15_Save_an_Edited_Staff_Record",0);
			}
			truclient_step("1.16.1", "Click on Create a new Staff button", "snapshot=Action_Staff_1.16.1.inf");
			truclient_step("1.16.2", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Staff_1.16.2.inf");
			truclient_step("1.16.3", "Save", "snapshot=Action_Staff_1.16.3.inf");
			{
				truclient_step("1.16.3.1", "Click on Name This field is required.... textbox", "snapshot=Action_Staff_1.16.3.1.inf");
				truclient_step("1.16.3.2", "Type newone in Name This field is required.... textbox", "snapshot=Action_Staff_1.16.3.2.inf");
				truclient_step("1.16.3.3", "Select Branchtwo from Branch BranchoneBranchtwo... listbox", "snapshot=Action_Staff_1.16.3.3.inf");
				lr_start_transaction("GAWEB_17_Add_a_Staff_Record");
				truclient_step("1.16.3.4", "Click on Save button", "snapshot=Action_Staff_1.16.3.4.inf");
				lr_end_transaction("GAWEB_17_Add_a_Staff_Record",0);
			}
		}
		truclient_step("1.17", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Staff_1.17.inf");
		lr_start_transaction("GAWEB_14_View_a_Staff_Record1");
		truclient_step("1.18", "Click on / View button", "snapshot=Action_Staff_1.18.inf");
		lr_end_transaction("GAWEB_14_View_a_Staff_Record1",0);
		truclient_step("1.19", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Staff_1.19.inf");
		lr_start_transaction("GAWEB_16_Back_from_View_Staff_Record1");
		truclient_step("1.20", "Click on Back button", "snapshot=Action_Staff_1.20.inf");
		lr_end_transaction("GAWEB_16_Back_from_View_Staff_Record1",0);
		truclient_step("1.21", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Staff_1.21.inf");
	}

	return 0;
}
