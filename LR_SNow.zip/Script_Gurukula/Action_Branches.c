//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action_Branches()
{
	truclient_step("1", "If ( TC.getParam('pgroupname'...== 'secondgroup' )", "snapshot=Action_Branches_1.inf");
	{
		truclient_step("1.1", "Click on Entities link", "snapshot=Action_Branches_1.1.inf");
		lr_start_transaction("GAWEB_04_Open_Branches_Page");
		truclient_step("1.2", "Click on Branch link", "snapshot=Action_Branches_1.2.inf");
		lr_end_transaction("GAWEB_04_Open_Branches_Page",0);
		truclient_step("1.3", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Branches_1.3.inf");
		truclient_step("1.4", "Click on Search Branch textbox", "snapshot=Action_Branches_1.4.inf");
		truclient_step("1.5", "Type TC.getParam('pSearchBranch') in Search Branch textbox", "snapshot=Action_Branches_1.5.inf");
		lr_start_transaction("GAWEB_05_Search_a_Branch");
		truclient_step("1.6", "Click on Search a Branch button", "snapshot=Action_Branches_1.6.inf");
		lr_end_transaction("GAWEB_05_Search_a_Branch",0);
		truclient_step("1.7", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Branches_1.7.inf");
		lr_start_transaction("GAWEB_06_View_a_Branch_Data");
		truclient_step("1.8", "Click on / View button", "snapshot=Action_Branches_1.8.inf");
		lr_end_transaction("GAWEB_06_View_a_Branch_Data",0);
		truclient_step("1.9", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Branches_1.9.inf");
		lr_start_transaction("GAWEB_09_Back_from_View_Branch_Record");
		truclient_step("1.10", "Click on Back button", "snapshot=Action_Branches_1.10.inf");
		lr_end_transaction("GAWEB_09_Back_from_View_Branch_Record",0);
		truclient_step("1.11", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Branches_1.11.inf");
		truclient_step("1.12", "Click on Search Branch textbox", "snapshot=Action_Branches_1.12.inf");
		truclient_step("1.13", "Type TC.getParam('pSearchBranch') in Search Branch textbox", "snapshot=Action_Branches_1.13.inf");
		lr_start_transaction("GAWEB_05_Search_a_Branch1");
		truclient_step("1.14", "Click on Search a Branch button", "snapshot=Action_Branches_1.14.inf");
		lr_end_transaction("GAWEB_05_Search_a_Branch1",0);
		truclient_step("1.15", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Branches_1.15.inf");
		lr_start_transaction("GAWEB_08_Open_a_Branch_Record_to_Edit");
		truclient_step("1.16", "Click on / Edit button", "snapshot=Action_Branches_1.16.inf");
		lr_end_transaction("GAWEB_08_Open_a_Branch_Record_to_Edit",0);
		truclient_step("1.17", "Wait TC.getParam('pttlow') seconds", "snapshot=Action_Branches_1.17.inf");
		truclient_step("1.18", "Save", "snapshot=Action_Branches_1.18.inf");
		{
			truclient_step("1.18.1", "Click on Code This field is required.... textbox", "snapshot=Action_Branches_1.18.1.inf");
			truclient_step("1.18.2", "Type var textArray = ['BC011'...ay[randomNumber] in Code This field is required.... textbox", "snapshot=Action_Branches_1.18.2.inf");
			lr_start_transaction("GAWEB_07_Save_Edited_Branch");
			truclient_step("1.18.3", "Click on Save button", "snapshot=Action_Branches_1.18.3.inf");
			lr_end_transaction("GAWEB_07_Save_Edited_Branch",0);
		}
		truclient_step("1.19", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Branches_1.19.inf");
		lr_start_transaction("GAWEB_06_View_a_Branch_Record1");
		truclient_step("1.20", "Click on / View button", "snapshot=Action_Branches_1.20.inf");
		lr_end_transaction("GAWEB_06_View_a_Branch_Record1",0);
		truclient_step("1.21", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Branches_1.21.inf");
		lr_start_transaction("GAWEB_09_Back_from_View_Branch_Record1");
		truclient_step("1.22", "Click on Back button", "snapshot=Action_Branches_1.22.inf");
		lr_end_transaction("GAWEB_09_Back_from_View_Branch_Record1",0);
		truclient_step("1.23", "Wait TC.getParam('pttmed') seconds", "snapshot=Action_Branches_1.23.inf");
	}

	return 0;
}
