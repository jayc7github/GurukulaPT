//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action_Admin()
{
	truclient_step("1", "If ( TC.getParam('pgroupname'... == 'firstgroup' )", "snapshot=Action_Admin_1.inf");
	{
		truclient_step("1.1", "Click on Account link", "snapshot=Action_Admin_1.1.inf");
		lr_start_transaction("GAWEB_98_Get_Active_User_Sessions");
		truclient_step("1.2", "Click on Sessions link", "snapshot=Action_Admin_1.2.inf");
		lr_end_transaction("GAWEB_98_Get_Active_User_Sessions",0);
		truclient_step("1.3", "Wait TC.getParam('psessionidle') seconds", "snapshot=Action_Admin_1.3.inf");
	}

	return 0;
}
