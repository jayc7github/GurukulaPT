//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Logout()
{
	truclient_step("1", "Click on Account link", "snapshot=Logout_1.inf");
	lr_start_transaction("GAWEB_99_Logout_from_Application");
	truclient_step("2", "Click on Log out link", "snapshot=Logout_2.inf");
	lr_end_transaction("GAWEB_99_Logout_from_Application",0);

	return 0;
}
