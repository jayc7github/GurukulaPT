//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Login()
{
	lr_start_transaction("GAWEB_01_Open_Landing_Page");
	truclient_step("1", "Navigate to TC.getParam('pEnv')", "snapshot=Login_1.inf");
	lr_end_transaction("GAWEB_01_Open_Landing_Page",0);
	lr_start_transaction("GAWEB_02_Open_Login_Page");
	truclient_step("2", "Click on login link", "snapshot=Login_2.inf");
	lr_end_transaction("GAWEB_02_Open_Login_Page",0);
	truclient_step("3", "Wait TC.getParam('pttlow') seconds", "snapshot=Login_3.inf");
	truclient_step("4", "Authenticate", "snapshot=Login_4.inf");
	{
		truclient_step("4.1", "Click on Login textbox", "snapshot=Login_4.1.inf");
		truclient_step("4.2", "Type TC.getParam('pUser') in Login textbox", "snapshot=Login_4.2.inf");
		truclient_step("4.3", "Type ******************* in Password passwordbox", "snapshot=Login_4.3.inf");
		lr_start_transaction("GAWEB_03_Login_to_Application");
		truclient_step("4.4", "Click on Authenticate button", "snapshot=Login_4.4.inf");
		lr_end_transaction("GAWEB_03_Login_to_Application",0);
	}
	truclient_step("5", "Wait TC.getParam('pttmed') seconds", "snapshot=Login_5.inf");

	return 0;
}
